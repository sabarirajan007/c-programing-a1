/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

#include <stdio.h>

/*C program to find the sum of digits*/

#include<stdio.h>  
#include<conio.h>  
void main()  
{  
// declare and initialize the variables  
int num, rem, sum = 0, i;  
// take an input from the user.  
printf("Enter a number\n");  
scanf("%d", &num);      
// find digits 

while(num>0){
                      
rem = num % 10;  
                            
sum = sum + rem; 

num=num/10;
}
                        
printf("the sum of digits %d", sum);

}